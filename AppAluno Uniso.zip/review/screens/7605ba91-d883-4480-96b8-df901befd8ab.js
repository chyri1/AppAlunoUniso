var content='<div class="ui-page" deviceName="androidpixel6" deviceType="mobile" deviceWidth="412" deviceHeight="778">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="412" height="778">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1668734493986.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-7605ba91-d883-4480-96b8-df901befd8ab" class="screen growth-vertical devMobile devAndroid android-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Login" width="412" height="778">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/7605ba91-d883-4480-96b8-df901befd8ab-1668734493986.css" />\
      <div class="freeLayout">\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="412.0px" datasizeheight="117.3px" dataX="0.0" dataY="-0.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/8ec0893c-fa4a-4b3f-b17a-9821cefec4bf.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="78.0px" datasizeheight="56.0px" dataX="167.0" dataY="50.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/bab7540c-cd0a-4f18-8dbe-53c9ff5807f4.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_24" class="richtext manualfit firer ie-background commentable non-processed" customid="Headline"   datasizewidth="69.8px" datasizeheight="31.0px" dataX="171.1" dataY="133.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_24_0">Login</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Dynamic_Panel_1" class="dynamicpanel firer commentable pin vpin-end hpin-beginning non-processed-pin non-processed" customid="Barra de navega&ccedil;&atilde;o" datasizewidth="412.0px" datasizeheight="48.0px" dataX="0.0" dataY="-0.0" >\
        <div id="s-Panel_1" class="panel default firer commentable non-processed" customid="Panel 1"  datasizewidth="412.0px" datasizeheight="48.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Rectangle_17" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="359.0px" datasizeheight="48.0px" datasizewidthpx="359.0" datasizeheightpx="48.00000000000006" dataX="26.5" dataY="0.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_17_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Path_22" class="path firer commentable non-processed" customid="Previous"   datasizewidth="17.0px" datasizeheight="19.7px" dataX="98.5" dataY="14.0"  >\
                  <div class="borderLayer">\
                  	<div class="imageViewport">\
                    	<?xml version="1.0" encoding="UTF-8"?>\
                    	<svg xmlns="http://www.w3.org/2000/svg" width="17.0" height="19.720354080200195" viewBox="98.50000001930151 13.99999999752696 17.0 19.720354080200195" preserveAspectRatio="none">\
                    	  <g>\
                    	    <defs>\
                    	      <path id="s-Path_22-7605b" d="M115.49409469125109 23.9013000355978 C115.49409469125109 26.71813236814371 115.50738163593576 29.521677452088923 115.49409469125109 32.33850978463484 C115.49409469125109 33.28188283051716 114.88289525753557 33.853221405429835 114.09896552015047 33.69377809693259 C113.80665273510797 33.62734337449923 113.51433995006546 33.481186981977984 113.24860106033202 33.32174365764148 C110.68422087577557 31.83360590047699 108.11984069121911 30.33218114814016 105.55545999980596 28.8440432642615 C103.56241832680509 27.688079119263826 101.58266364897655 26.518827979093814 99.58962172254732 25.362863707381962 C98.15463169264386 24.52578617937876 98.12805782901336 23.23695258951436 99.563047833178 22.386588193052994 C104.10718316480141 19.715912522295955 108.65131828061476 17.058523624961456 113.19545288957138 14.3878477958117 C113.31503538678358 14.321413073378338 113.42133095218051 14.254978350944976 113.54091343355344 14.188543628511614 C114.59058206067199 13.683639744353766 115.4808073792933 14.228404463555558 115.49409424775146 15.397655627484482 C115.50738143299507 18.227774638417294 115.49409469125109 21.071180961307892 115.49409469125109 23.9013000355978 C115.49409469125109 23.9013000355978 115.49409469125109 23.9013000355978 115.49409469125109 23.9013000355978 Z M113.23531412851676 30.757363187978125 C113.23531412851676 26.080358627298065 113.23531412851676 21.576084750430105 113.23531412851676 16.92565418009473 C109.275804266003 19.26415620700641 105.42259036486797 21.52293676974073 101.42322027712223 23.87472655210982 C105.46245160381335 26.226515320765486 109.30237876320439 28.458722400011837 113.23531412851676 30.757363187978125 Z "></path>\
                    	    </defs>\
                    	    <g style="mix-blend-mode:normal">\
                    	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_22-7605b" fill="#000000" fill-opacity="1.0"></use>\
                    	    </g>\
                    	  </g>\
                    	</svg>\
\
                    </div>\
                  </div>\
                </div>\
                <div id="shapewrapper-s-Ellipse_1" customid="Ellipse" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="20.0px" datasizeheight="20.0px" datasizewidthpx="20.0" datasizeheightpx="20.0" dataX="195.5" dataY="14.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
                        <g>\
                            <g clip-path="url(#clip-s-Ellipse_1)">\
                                    <ellipse id="s-Ellipse_1" class="ellipse shape non-processed-shape manualfit firer ie-background commentable non-processed" customid="Ellipse" cx="10.0" cy="10.0" rx="10.0" ry="10.0">\
                                    </ellipse>\
                            </g>\
                        </g>\
                        <defs>\
                            <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                                    <ellipse cx="10.0" cy="10.0" rx="10.0" ry="10.0">\
                                    </ellipse>\
                            </clipPath>\
                        </defs>\
                    </svg>\
                    <div class="paddingLayer">\
                        <div id="shapert-s-Ellipse_1" class="content firer" >\
                            <div class="valign">\
                                <span id="rtr-s-Ellipse_1_0"></span>\
                            </div>\
                        </div>\
                    </div>\
                </div>\
                <div id="s-Rectangle_18" class="rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle"   datasizewidth="19.0px" datasizeheight="19.0px" datasizewidthpx="19.0" datasizeheightpx="19.0" dataX="294.5" dataY="15.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_18_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_19" class="group firer ie-background commentable non-processed" customid="Caixas de texto" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_19" class="rectangle manualfit firer click commentable non-processed" customid="bg"   datasizewidth="56.0px" datasizeheight="56.0px" datasizewidthpx="56.0" datasizeheightpx="56.0" dataX="341.3" dataY="663.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_19_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_25" class="path firer commentable non-processed" customid="Save"   datasizewidth="23.5px" datasizeheight="23.5px" dataX="357.5" dataY="679.2"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="23.51228904724121" height="23.51228904724121" viewBox="357.53632779516334 679.2485454821708 23.51228904724121 23.51228904724121" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_25-7605b" d="M375.82366354720824 679.2485454821708 L360.14880433116974 679.2485454821708 C358.6988798350003 679.2485454821708 357.53632779516334 680.4241598922306 357.53632779516334 681.8610220181772 L357.53632779516334 700.148357770222 C357.53632779516334 701.5852198961687 358.6988798350003 702.7608343062284 360.14880433116974 702.7608343062284 L378.43614008321464 702.7608343062284 C379.8730022091613 702.7608343062284 381.04861661922104 701.5852198961687 381.04861661922104 700.148357770222 L381.04861661922104 684.4734985541836 L375.82366354720824 679.2485454821708 Z M369.2924722071922 700.148357770222 C367.1241167259073 700.148357770222 365.3737574031826 698.3979984474973 365.3737574031826 696.2296429662124 C365.3737574031826 694.0612874849276 367.1241167259073 692.3109281622028 369.2924722071922 692.3109281622028 C371.46082768847714 692.3109281622028 373.2111870112018 694.0612874849276 373.2111870112018 696.2296429662124 C373.2111870112018 698.3979984474973 371.46082768847714 700.148357770222 369.2924722071922 700.148357770222 Z M373.2111870112018 687.08597509019 L360.14880433116974 687.08597509019 L360.14880433116974 681.8610220181772 L373.2111870112018 681.8610220181772 L373.2111870112018 687.08597509019 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_25-7605b" fill="#00A3D9" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Input_3" class="inputAndroid checkbox firer commentable non-processed unchecked" customid="Checkbox Web"  datasizewidth="13.0px" datasizeheight="13.0px" dataX="323.7" dataY="684.5"      tabindex="-1">\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
        </div>\
        <div id="s-Button_5" class="button multiline manualfit firer click commentable non-processed" customid="Enviar"   datasizewidth="129.0px" datasizeheight="40.0px" dataX="231.5" dataY="369.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_5_0">Enviar</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_4" class="button multiline manualfit firer click commentable non-processed" customid="Esqueci minha senha"   datasizewidth="143.0px" datasizeheight="58.0px" dataX="51.5" dataY="360.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_4_0">Esqueci minha senha</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Input_2" class="text firer focusin focusout commentable non-processed" customid="Input"  datasizewidth="309.0px" datasizeheight="59.0px" dataX="51.5" dataY="287.8" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="@Exemplo123"/></div></div>  </div></div></div>\
        <div id="s-Paragraph_19" class="richtext autofit firer commentable non-processed" customid="Senha"   datasizewidth="46.5px" datasizeheight="25.0px" dataX="64.0" dataY="275.3" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_19_0">Senha</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Input_1" class="text firer focusin focusout commentable non-processed" customid="Input"  datasizewidth="309.0px" datasizeheight="59.0px" dataX="51.5" dataY="203.8" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="exemplo@gmail.com"/></div></div>  </div></div></div>\
        <div id="s-Paragraph_18" class="richtext autofit firer commentable non-processed" customid="Email"   datasizewidth="42.6px" datasizeheight="25.0px" dataX="64.0" dataY="191.3" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_18_0">Email</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;
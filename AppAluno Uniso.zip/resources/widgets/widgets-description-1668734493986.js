	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Image_1", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_2", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Paragraph_24", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_24", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ["Headline Small", "s-Paragraph_24"]; 

	widgets.descriptionMap[["s-Rectangle_17", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_17", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ["Softkeys light", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_22", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ""; 

			widgets.rootWidgetMap[["s-Path_22", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ["Softkeys light", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Ellipse_1", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ["Softkeys light", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_18", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_18", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ["Softkeys light", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_1", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ["Softkeys light", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_19", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_19", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ["Input with label", "s-Group_19"]; 

	widgets.descriptionMap[["s-Path_25", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ""; 

			widgets.rootWidgetMap[["s-Path_25", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ["Save", "s-Path_25"]; 

	widgets.descriptionMap[["s-Input_3", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ""; 

			widgets.rootWidgetMap[["s-Input_3", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ["Check web", "s-Input_3"]; 

	widgets.descriptionMap[["s-Button_5", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ""; 

			widgets.rootWidgetMap[["s-Button_5", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ["Filled", "s-Button_5"]; 

	widgets.descriptionMap[["s-Button_4", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ["Outlined", "s-Button_4"]; 

	widgets.descriptionMap[["s-Input_2", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ["Input with label", "s-Group_19"]; 

	widgets.descriptionMap[["s-Paragraph_19", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_19", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ["Input with label", "s-Group_19"]; 

	widgets.descriptionMap[["s-Input_1", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ["Input with label", "s-Group_19"]; 

	widgets.descriptionMap[["s-Paragraph_18", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_18", "7605ba91-d883-4480-96b8-df901befd8ab"]] = ["Input with label", "s-Group_19"]; 

	widgets.descriptionMap[["s-Rectangle_16", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_19", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_19", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_20", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_20", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_2", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_2", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_5", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_5", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_19", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_19", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_21", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_21", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Dollar", "s-Path_21"]; 

	widgets.descriptionMap[["s-Hotspot_3", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_3", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_6", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_6", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_20", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_20", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_23", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_23", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Email", "s-Path_23"]; 

	widgets.descriptionMap[["s-Hotspot_4", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_4", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_7", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_7", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_21", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_21", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_24", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_24", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["User", "s-Path_24"]; 

	widgets.descriptionMap[["s-Hotspot_5", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_5", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_8", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_8", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Panel_2", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_2", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation bar", "s-Dynamic_Panel_2"]; 

	widgets.descriptionMap[["s-Image_1", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_2", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Path_1", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["View stream", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Menu", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Brightness medium", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_5", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["View week", "s-Path_5"]; 

	widgets.descriptionMap[["s-Rectangle_17", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_17", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Softkeys light", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_22", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_22", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Softkeys light", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Ellipse_1", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Softkeys light", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_18", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_18", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Softkeys light", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_1", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Softkeys light", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Paragraph_18", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_18", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Headline Small", "s-Paragraph_18"]; 

	widgets.descriptionMap[["s-Rectangle_1", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Menu minimum width", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_2", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Menu minimum width", "s-Group_2"]; 

	widgets.descriptionMap[["s-Paragraph_1", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Menu minimum width", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_3", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Menu minimum width", "s-Group_2"]; 

	widgets.descriptionMap[["s-Paragraph_2", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Menu minimum width", "s-Group_2"]; 

	widgets.descriptionMap[["s-Hotspot_1", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_1", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Basic with icons", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_22", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Button_22", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Outlined button", "s-Button_22"]; 

	widgets.descriptionMap[["s-Button_23", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Button_23", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Outlined button", "s-Button_23"]; 

	widgets.descriptionMap[["s-Paragraph_56", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_56", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Body large", "s-Paragraph_56"]; 

	widgets.descriptionMap[["s-Paragraph_53", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_53", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Body small", "s-Paragraph_53"]; 

	widgets.descriptionMap[["s-Ellipse_8", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_8", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Path_200", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_200", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Ellipse_7", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_7", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Paragraph_57", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_57", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Body large", "s-Paragraph_57"]; 

	widgets.descriptionMap[["s-Paragraph_54", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_54", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Body small", "s-Paragraph_54"]; 

	widgets.descriptionMap[["s-Path_201", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_201", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Ellipse_6", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_6", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Paragraph_55", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_55", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Body small", "s-Paragraph_55"]; 

	widgets.descriptionMap[["s-Paragraph_58", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_58", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Body large", "s-Paragraph_58"]; 

	widgets.descriptionMap[["s-Path_202", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_202", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Paragraph_59", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_59", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Body large", "s-Paragraph_59"]; 

	widgets.descriptionMap[["s-Paragraph_60", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_60", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Body small", "s-Paragraph_60"]; 

	widgets.descriptionMap[["s-Ellipse_9", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_9", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Path_203", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_203", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Ellipse_10", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_10", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Paragraph_61", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_61", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Body large", "s-Paragraph_61"]; 

	widgets.descriptionMap[["s-Paragraph_62", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_62", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Body small", "s-Paragraph_62"]; 

	widgets.descriptionMap[["s-Path_204", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_204", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Ellipse_11", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_11", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Paragraph_63", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_63", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Body small", "s-Paragraph_63"]; 

	widgets.descriptionMap[["s-Paragraph_64", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_64", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Body large", "s-Paragraph_64"]; 

	widgets.descriptionMap[["s-Path_211", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_211", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Path_205", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_205", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Input_1", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Check web", "s-Input_1"]; 

	widgets.descriptionMap[["s-Input_2", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Check web", "s-Input_2"]; 

	widgets.descriptionMap[["s-Input_3", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Input_3", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Check web", "s-Input_3"]; 

	widgets.descriptionMap[["s-Input_4", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Input_4", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Check web", "s-Input_4"]; 

	widgets.descriptionMap[["s-Input_5", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Input_5", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Check web", "s-Input_5"]; 

	widgets.descriptionMap[["s-Path_25", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_25", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["View week", "s-Path_25"]; 

	widgets.descriptionMap[["s-Path_4", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_4", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_5", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Path_6", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Path_7", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_6", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_3", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_7", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_7", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_4", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_8", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_5", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_9", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_9", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_6", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_10", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_10", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_7", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_11", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_11", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_8", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_12", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_12", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_9", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_13", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_13", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_10", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_14", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_14", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_11", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_11", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_15", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_15", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_12", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_12", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_13", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_13", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_14", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_14", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_15", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_15", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_16", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_16", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_17", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_17", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Path_8", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Dollar", "s-Path_8"]; 

	widgets.descriptionMap[["s-Path_9", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Email", "s-Path_9"]; 

	widgets.descriptionMap[["s-Path_10", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Account circle", "s-Path_10"]; 

	widgets.descriptionMap[["s-Path_11", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Learn", "s-Path_11"]; 

	widgets.descriptionMap[["s-Path_12", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_12", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Quote", "s-Path_12"]; 

	widgets.descriptionMap[["s-Path_13", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_13", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Gesture", "s-Path_13"]; 

	widgets.descriptionMap[["s-Path_14", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_14", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Videocam", "s-Path_14"]; 

	widgets.descriptionMap[["s-Path_15", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Book", "s-Path_15"]; 

	widgets.descriptionMap[["s-Path_16", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_16", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["More horizontal", "s-Path_16"]; 

	widgets.descriptionMap[["s-Path_17", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_17", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Clock", "s-Group_17"]; 

	widgets.descriptionMap[["s-Path_18", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ""; 

			widgets.rootWidgetMap[["s-Path_18", "79498c0b-49b0-46ef-80be-7757a4ada859"]] = ["Clock", "s-Group_17"]; 

	widgets.descriptionMap[["s-Rectangle_3", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "0d085857-028e-492b-867d-a316088a856b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_7", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "0d085857-028e-492b-867d-a316088a856b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_8", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "0d085857-028e-492b-867d-a316088a856b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_2", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_2", "0d085857-028e-492b-867d-a316088a856b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_5", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_5", "0d085857-028e-492b-867d-a316088a856b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_19", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_19", "0d085857-028e-492b-867d-a316088a856b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_9", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "0d085857-028e-492b-867d-a316088a856b"]] = ["Dollar", "s-Path_9"]; 

	widgets.descriptionMap[["s-Hotspot_3", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_3", "0d085857-028e-492b-867d-a316088a856b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_6", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_6", "0d085857-028e-492b-867d-a316088a856b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_20", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_20", "0d085857-028e-492b-867d-a316088a856b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_10", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "0d085857-028e-492b-867d-a316088a856b"]] = ["Email", "s-Path_10"]; 

	widgets.descriptionMap[["s-Hotspot_4", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_4", "0d085857-028e-492b-867d-a316088a856b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_7", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_7", "0d085857-028e-492b-867d-a316088a856b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_21", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_21", "0d085857-028e-492b-867d-a316088a856b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_11", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "0d085857-028e-492b-867d-a316088a856b"]] = ["User", "s-Path_11"]; 

	widgets.descriptionMap[["s-Hotspot_5", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_5", "0d085857-028e-492b-867d-a316088a856b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_8", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_8", "0d085857-028e-492b-867d-a316088a856b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Panel_2", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_2", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation bar", "s-Dynamic_Panel_2"]; 

	widgets.descriptionMap[["s-Rectangle_1", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "0d085857-028e-492b-867d-a316088a856b"]] = ["Softkeys light", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_1", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "0d085857-028e-492b-867d-a316088a856b"]] = ["Softkeys light", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Ellipse_1", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "0d085857-028e-492b-867d-a316088a856b"]] = ["Softkeys light", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "0d085857-028e-492b-867d-a316088a856b"]] = ["Softkeys light", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_1", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "0d085857-028e-492b-867d-a316088a856b"]] = ["Softkeys light", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Image_1", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "0d085857-028e-492b-867d-a316088a856b"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_2", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "0d085857-028e-492b-867d-a316088a856b"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Path_3", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "0d085857-028e-492b-867d-a316088a856b"]] = ["View stream", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "0d085857-028e-492b-867d-a316088a856b"]] = ["Menu", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "0d085857-028e-492b-867d-a316088a856b"]] = ["Brightness medium", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_14", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_14", "0d085857-028e-492b-867d-a316088a856b"]] = ["View week", "s-Path_14"]; 

	widgets.descriptionMap[["s-Paragraph_18", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_18", "0d085857-028e-492b-867d-a316088a856b"]] = ["Headline Small", "s-Paragraph_18"]; 

	widgets.descriptionMap[["s-Button_4", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "0d085857-028e-492b-867d-a316088a856b"]] = ["Suggestion", "s-Button_4"]; 

	widgets.descriptionMap[["s-Button_5", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Button_5", "0d085857-028e-492b-867d-a316088a856b"]] = ["Suggestion", "s-Button_5"]; 

	widgets.descriptionMap[["s-Button_6", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "0d085857-028e-492b-867d-a316088a856b"]] = ["Suggestion", "s-Button_6"]; 

	widgets.descriptionMap[["s-Button_7", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Button_7", "0d085857-028e-492b-867d-a316088a856b"]] = ["Suggestion", "s-Button_7"]; 

	widgets.descriptionMap[["s-Button_8", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Button_8", "0d085857-028e-492b-867d-a316088a856b"]] = ["Suggestion", "s-Button_8"]; 

	widgets.descriptionMap[["s-Button_9", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Button_9", "0d085857-028e-492b-867d-a316088a856b"]] = ["Suggestion", "s-Button_9"]; 

	widgets.descriptionMap[["s-Rectangle_16", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "0d085857-028e-492b-867d-a316088a856b"]] = ["Menu minimum width", "s-Group_16"]; 

	widgets.descriptionMap[["s-Rectangle_17", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_17", "0d085857-028e-492b-867d-a316088a856b"]] = ["Menu minimum width", "s-Group_16"]; 

	widgets.descriptionMap[["s-Paragraph_16", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_16", "0d085857-028e-492b-867d-a316088a856b"]] = ["Menu minimum width", "s-Group_16"]; 

	widgets.descriptionMap[["s-Rectangle_18", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_18", "0d085857-028e-492b-867d-a316088a856b"]] = ["Menu minimum width", "s-Group_16"]; 

	widgets.descriptionMap[["s-Paragraph_17", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_17", "0d085857-028e-492b-867d-a316088a856b"]] = ["Menu minimum width", "s-Group_16"]; 

	widgets.descriptionMap[["s-Hotspot_1", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_1", "0d085857-028e-492b-867d-a316088a856b"]] = ["Basic with icons", "s-Group_15"]; 

	widgets.descriptionMap[["s-Path_2", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation drawer", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_4", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation drawer", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_5", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation drawer", "s-Group_2"]; 

	widgets.descriptionMap[["s-Path_6", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation drawer", "s-Group_2"]; 

	widgets.descriptionMap[["s-Path_12", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_12", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation drawer", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_6", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation drawer", "s-Group_2"]; 

	widgets.descriptionMap[["s-Paragraph_1", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation drawer", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_7", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_7", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation drawer", "s-Group_2"]; 

	widgets.descriptionMap[["s-Paragraph_2", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation drawer", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_8", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation drawer", "s-Group_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation drawer", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_9", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_9", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation drawer", "s-Group_2"]; 

	widgets.descriptionMap[["s-Paragraph_4", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation drawer", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_10", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_10", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation drawer", "s-Group_2"]; 

	widgets.descriptionMap[["s-Paragraph_5", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation drawer", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_11", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_11", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation drawer", "s-Group_2"]; 

	widgets.descriptionMap[["s-Paragraph_6", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation drawer", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_12", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_12", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation drawer", "s-Group_2"]; 

	widgets.descriptionMap[["s-Paragraph_7", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation drawer", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_13", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_13", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation drawer", "s-Group_2"]; 

	widgets.descriptionMap[["s-Paragraph_8", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation drawer", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_14", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_14", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation drawer", "s-Group_2"]; 

	widgets.descriptionMap[["s-Paragraph_9", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation drawer", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_15", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_15", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation drawer", "s-Group_2"]; 

	widgets.descriptionMap[["s-Paragraph_10", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation drawer", "s-Group_2"]; 

	widgets.descriptionMap[["s-Paragraph_11", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_11", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation drawer", "s-Group_2"]; 

	widgets.descriptionMap[["s-Paragraph_12", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_12", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation drawer", "s-Group_2"]; 

	widgets.descriptionMap[["s-Paragraph_13", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_13", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation drawer", "s-Group_2"]; 

	widgets.descriptionMap[["s-Paragraph_14", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_14", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation drawer", "s-Group_2"]; 

	widgets.descriptionMap[["s-Paragraph_15", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_15", "0d085857-028e-492b-867d-a316088a856b"]] = ["Navigation drawer", "s-Group_2"]; 

	widgets.descriptionMap[["s-Path_13", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_13", "0d085857-028e-492b-867d-a316088a856b"]] = ["Dollar", "s-Path_13"]; 

	widgets.descriptionMap[["s-Path_15", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "0d085857-028e-492b-867d-a316088a856b"]] = ["Email", "s-Path_15"]; 

	widgets.descriptionMap[["s-Path_16", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_16", "0d085857-028e-492b-867d-a316088a856b"]] = ["Account circle", "s-Path_16"]; 

	widgets.descriptionMap[["s-Path_17", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_17", "0d085857-028e-492b-867d-a316088a856b"]] = ["Learn", "s-Path_17"]; 

	widgets.descriptionMap[["s-Path_18", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_18", "0d085857-028e-492b-867d-a316088a856b"]] = ["Quote", "s-Path_18"]; 

	widgets.descriptionMap[["s-Path_19", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_19", "0d085857-028e-492b-867d-a316088a856b"]] = ["Gesture", "s-Path_19"]; 

	widgets.descriptionMap[["s-Path_20", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_20", "0d085857-028e-492b-867d-a316088a856b"]] = ["Videocam", "s-Path_20"]; 

	widgets.descriptionMap[["s-Path_21", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_21", "0d085857-028e-492b-867d-a316088a856b"]] = ["Book", "s-Path_21"]; 

	widgets.descriptionMap[["s-Path_22", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_22", "0d085857-028e-492b-867d-a316088a856b"]] = ["More horizontal", "s-Path_22"]; 

	widgets.descriptionMap[["s-Path_23", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_23", "0d085857-028e-492b-867d-a316088a856b"]] = ["Clock", "s-Group_14"]; 

	widgets.descriptionMap[["s-Path_24", "0d085857-028e-492b-867d-a316088a856b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_24", "0d085857-028e-492b-867d-a316088a856b"]] = ["Clock", "s-Group_14"]; 

	widgets.descriptionMap[["s-Rectangle_6", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_6", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_7", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_2", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_2", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_5", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_5", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_19", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_19", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_8", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Dollar", "s-Path_8"]; 

	widgets.descriptionMap[["s-Hotspot_3", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_3", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_6", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_6", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_20", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_20", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_23", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Path_23", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Email", "s-Path_23"]; 

	widgets.descriptionMap[["s-Hotspot_4", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_4", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_7", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_7", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_21", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_21", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_24", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Path_24", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["User", "s-Path_24"]; 

	widgets.descriptionMap[["s-Hotspot_5", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_5", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_8", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_8", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Panel_2", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_2", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation bar", "s-Dynamic_Panel_2"]; 

	widgets.descriptionMap[["s-Rectangle_4", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Softkeys light", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_1", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Softkeys light", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Ellipse_1", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Softkeys light", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_5", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Softkeys light", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_1", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Softkeys light", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Image_1", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_2", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Path_2", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["View stream", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Menu", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Brightness medium", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["View week", "s-Path_5"]; 

	widgets.descriptionMap[["s-Paragraph_3", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Headline Small", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Button_4", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Suggestion", "s-Button_4"]; 

	widgets.descriptionMap[["s-Button_5", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Button_5", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Suggestion", "s-Button_5"]; 

	widgets.descriptionMap[["s-Button_6", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Suggestion", "s-Button_6"]; 

	widgets.descriptionMap[["s-Button_7", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Button_7", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Suggestion", "s-Button_7"]; 

	widgets.descriptionMap[["s-Button_8", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Button_8", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Suggestion", "s-Button_8"]; 

	widgets.descriptionMap[["s-Button_9", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Button_9", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Suggestion", "s-Button_9"]; 

	widgets.descriptionMap[["s-Rectangle_1", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Menu minimum width", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_2", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Menu minimum width", "s-Group_2"]; 

	widgets.descriptionMap[["s-Paragraph_1", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Menu minimum width", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_3", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Menu minimum width", "s-Group_2"]; 

	widgets.descriptionMap[["s-Paragraph_2", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Menu minimum width", "s-Group_2"]; 

	widgets.descriptionMap[["s-Hotspot_1", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_1", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Basic with icons", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_9", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_7", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_7", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_8", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Path_10", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Path_11", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_9", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_9", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_4", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_10", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_10", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_5", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_11", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_11", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_6", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_12", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_12", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_7", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_13", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_13", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_8", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_14", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_14", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_9", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_15", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_15", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_10", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_16", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_11", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_11", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_17", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_17", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_12", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_12", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_18", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_18", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_13", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_13", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_14", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_14", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_15", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_15", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_16", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_16", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_17", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_17", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_18", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_18", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Path_12", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Path_12", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Dollar", "s-Path_12"]; 

	widgets.descriptionMap[["s-Path_13", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Path_13", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Email", "s-Path_13"]; 

	widgets.descriptionMap[["s-Path_14", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Path_14", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Account circle", "s-Path_14"]; 

	widgets.descriptionMap[["s-Path_15", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Learn", "s-Path_15"]; 

	widgets.descriptionMap[["s-Path_16", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Path_16", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Quote", "s-Path_16"]; 

	widgets.descriptionMap[["s-Path_17", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Path_17", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Gesture", "s-Path_17"]; 

	widgets.descriptionMap[["s-Path_18", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Path_18", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Videocam", "s-Path_18"]; 

	widgets.descriptionMap[["s-Path_19", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Path_19", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Book", "s-Path_19"]; 

	widgets.descriptionMap[["s-Path_20", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Path_20", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["More horizontal", "s-Path_20"]; 

	widgets.descriptionMap[["s-Path_21", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Path_21", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Clock", "s-Group_17"]; 

	widgets.descriptionMap[["s-Path_22", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ""; 

			widgets.rootWidgetMap[["s-Path_22", "fd348695-5a87-4b52-8995-1c4f1f396771"]] = ["Clock", "s-Group_17"]; 

	widgets.descriptionMap[["s-Rectangle_19", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_19", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_25", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_25", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_26", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_26", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_2", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_2", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_5", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_5", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_23", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_23", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_27", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_27", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Dollar", "s-Path_27"]; 

	widgets.descriptionMap[["s-Hotspot_3", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_3", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_6", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_6", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_24", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_24", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_28", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_28", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Email", "s-Path_28"]; 

	widgets.descriptionMap[["s-Hotspot_4", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_4", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_7", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_7", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_25", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_25", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_29", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_29", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["User", "s-Path_29"]; 

	widgets.descriptionMap[["s-Hotspot_5", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_5", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_8", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_8", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Panel_2", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_2", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation bar", "s-Dynamic_Panel_2"]; 

	widgets.descriptionMap[["s-Image_1", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_2", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Path_1", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["View stream", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Menu", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Brightness medium", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_5", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["View week", "s-Path_5"]; 

	widgets.descriptionMap[["s-Rectangle_17", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_17", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Softkeys light", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_22", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_22", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Softkeys light", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Ellipse_1", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Softkeys light", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_18", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_18", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Softkeys light", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_1", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Softkeys light", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_20", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_20", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Basic", "s-Group_19"]; 

	widgets.descriptionMap[["s-Paragraph_18", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_18", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Headline Small", "s-Paragraph_18"]; 

	widgets.descriptionMap[["s-Paragraph_19", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_19", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Basic", "s-Group_19"]; 

	widgets.descriptionMap[["s-Rectangle_21", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_21", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Basic", "s-Group_20"]; 

	widgets.descriptionMap[["s-Paragraph_20", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_20", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Headline Small", "s-Paragraph_20"]; 

	widgets.descriptionMap[["s-Paragraph_21", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_21", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Basic", "s-Group_20"]; 

	widgets.descriptionMap[["s-Rectangle_22", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_22", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Basic", "s-Group_21"]; 

	widgets.descriptionMap[["s-Paragraph_22", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_22", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Headline Small", "s-Paragraph_22"]; 

	widgets.descriptionMap[["s-Paragraph_23", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_23", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Basic", "s-Group_21"]; 

	widgets.descriptionMap[["s-Paragraph_24", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_24", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Headline Small", "s-Paragraph_24"]; 

	widgets.descriptionMap[["s-Rectangle_1", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Menu minimum width", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_2", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Menu minimum width", "s-Group_2"]; 

	widgets.descriptionMap[["s-Paragraph_1", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Menu minimum width", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_3", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Menu minimum width", "s-Group_2"]; 

	widgets.descriptionMap[["s-Paragraph_2", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Menu minimum width", "s-Group_2"]; 

	widgets.descriptionMap[["s-Hotspot_1", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_1", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Basic with icons", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_4", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_4", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_5", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Path_6", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Path_7", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_6", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_3", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_7", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_7", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_4", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_8", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_5", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_9", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_9", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_6", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_10", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_10", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_7", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_11", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_11", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_8", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_12", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_12", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_9", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_13", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_13", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_10", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_14", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_14", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_11", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_11", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_15", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_15", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_12", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_12", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_13", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_13", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_14", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_14", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_15", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_15", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_16", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_16", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_17", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_17", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Navigation drawer", "s-Group_5"]; 

	widgets.descriptionMap[["s-Path_8", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Dollar", "s-Path_8"]; 

	widgets.descriptionMap[["s-Path_9", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Email", "s-Path_9"]; 

	widgets.descriptionMap[["s-Path_10", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Account circle", "s-Path_10"]; 

	widgets.descriptionMap[["s-Path_11", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Learn", "s-Path_11"]; 

	widgets.descriptionMap[["s-Path_12", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_12", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Quote", "s-Path_12"]; 

	widgets.descriptionMap[["s-Path_13", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_13", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Gesture", "s-Path_13"]; 

	widgets.descriptionMap[["s-Path_14", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_14", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Videocam", "s-Path_14"]; 

	widgets.descriptionMap[["s-Path_15", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Book", "s-Path_15"]; 

	widgets.descriptionMap[["s-Path_16", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_16", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["More horizontal", "s-Path_16"]; 

	widgets.descriptionMap[["s-Path_17", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_17", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Clock", "s-Group_17"]; 

	widgets.descriptionMap[["s-Path_18", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_18", "e9a9523c-cc73-4d87-bee5-6489684988bc"]] = ["Clock", "s-Group_17"]; 

	widgets.descriptionMap[["s-Rectangle_4", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Softkeys light", "s-Dynamic_Panel_2"]; 

	widgets.descriptionMap[["s-Path_1", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Softkeys light", "s-Dynamic_Panel_2"]; 

	widgets.descriptionMap[["s-Ellipse_1", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Softkeys light", "s-Dynamic_Panel_2"]; 

	widgets.descriptionMap[["s-Rectangle_5", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Softkeys light", "s-Dynamic_Panel_2"]; 

	widgets.descriptionMap[["s-Panel_2", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_2", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Softkeys light", "s-Dynamic_Panel_2"]; 

	widgets.descriptionMap[["s-Image_1", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_2", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Path_2", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["View stream", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Menu", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Brightness medium", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["View week", "s-Path_5"]; 

	widgets.descriptionMap[["s-Button_1", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Tonal", "s-Button_1"]; 

	widgets.descriptionMap[["s-Button_2", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Tonal", "s-Button_2"]; 

	widgets.descriptionMap[["s-Button_3", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Tonal", "s-Button_3"]; 

	widgets.descriptionMap[["s-Path_6", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Dollar", "s-Path_6"]; 

	widgets.descriptionMap[["s-Rectangle_6", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Clock", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_7", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["User", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_8", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Email", "s-Path_8"]; 

	widgets.descriptionMap[["s-Path_9", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Clock", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_10", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Clock", "s-Group_1"]; 

	widgets.descriptionMap[["s-Rectangle_28", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_28", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Table", "s-Table_6"]; 

	widgets.descriptionMap[["s-Path_11", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Table", "s-Table_6"]; 

	widgets.descriptionMap[["s-Path_12", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Path_12", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Table", "s-Table_6"]; 

	widgets.descriptionMap[["s-Hotspot_14", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_14", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Table", "s-Table_6"]; 

	widgets.descriptionMap[["s-Cell_36", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_36", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Table", "s-Table_6"]; 

	widgets.descriptionMap[["s-Rectangle_29", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_29", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Table", "s-Table_6"]; 

	widgets.descriptionMap[["s-Path_13", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Path_13", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Dollar", "s-Path_13"]; 

	widgets.descriptionMap[["s-Hotspot_13", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_13", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Table", "s-Table_6"]; 

	widgets.descriptionMap[["s-Cell_54", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_54", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Table", "s-Table_6"]; 

	widgets.descriptionMap[["s-Rectangle_30", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_30", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Table", "s-Table_6"]; 

	widgets.descriptionMap[["s-Path_15", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Email", "s-Path_15"]; 

	widgets.descriptionMap[["s-Hotspot_12", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_12", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Table", "s-Table_6"]; 

	widgets.descriptionMap[["s-Cell_55", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_55", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Table", "s-Table_6"]; 

	widgets.descriptionMap[["s-Rectangle_31", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_31", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Table", "s-Table_6"]; 

	widgets.descriptionMap[["s-Path_14", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Path_14", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["User", "s-Path_14"]; 

	widgets.descriptionMap[["s-Hotspot_11", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_11", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Table", "s-Table_6"]; 

	widgets.descriptionMap[["s-Cell_56", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_56", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Table", "s-Table_6"]; 

	widgets.descriptionMap[["s-Panel_4", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_4", "7079afc0-5274-4ccc-ae86-fe1805e8e611"]] = ["Navigation bar", "s-Dynamic_Panel_3"]; 

	widgets.descriptionMap[["s-Rectangle_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_18", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_18", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_19", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_19", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_29", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_29", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_20", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_20", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Dollar", "s-Path_20"]; 

	widgets.descriptionMap[["s-Hotspot_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_30", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_30", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_21", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_21", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Email", "s-Path_21"]; 

	widgets.descriptionMap[["s-Hotspot_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_31", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_31", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_22", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_22", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["User", "s-Path_22"]; 

	widgets.descriptionMap[["s-Hotspot_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Panel_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation bar", "s-Dynamic_Panel_2"]; 

	widgets.descriptionMap[["s-Rectangle_26", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_26", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Card switch", "s-Group_18"]; 

	widgets.descriptionMap[["s-Paragraph_35", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_35", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Title Small", "s-Paragraph_35"]; 

	widgets.descriptionMap[["s-Input_9", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Input_9", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Switch button", "s-Input_9"]; 

	widgets.descriptionMap[["s-Button_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Filled", "s-Button_7"]; 

	widgets.descriptionMap[["s-Button_9", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button_9", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Outlined button", "s-Button_9"]; 

	widgets.descriptionMap[["s-Rectangle_24", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_24", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Card switch", "s-Group_18"]; 

	widgets.descriptionMap[["s-Rectangle_25", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_25", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Card switch", "s-Group_18"]; 

	widgets.descriptionMap[["s-Path_123", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_123", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Arrow forward", "s-Path_123"]; 

	widgets.descriptionMap[["s-Path_117", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_117", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Arrow back", "s-Path_117"]; 

	widgets.descriptionMap[["s-Path_476", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_476", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["View list", "s-Path_476"]; 

	widgets.descriptionMap[["s-Image_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Rectangle_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Softkeys light", "s-Dynamic_Panel_3"]; 

	widgets.descriptionMap[["s-Path_157", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_157", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Softkeys light", "s-Dynamic_Panel_3"]; 

	widgets.descriptionMap[["s-Ellipse_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Softkeys light", "s-Dynamic_Panel_3"]; 

	widgets.descriptionMap[["s-Rectangle_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Softkeys light", "s-Dynamic_Panel_3"]; 

	widgets.descriptionMap[["s-Panel_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Softkeys light", "s-Dynamic_Panel_3"]; 

	widgets.descriptionMap[["s-Image", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Path_478", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_478", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["View stream", "s-Path_478"]; 

	widgets.descriptionMap[["s-Path_147", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_147", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Menu", "s-Path_147"]; 

	widgets.descriptionMap[["s-Path_240", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_240", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Brightness medium", "s-Path_240"]; 

	widgets.descriptionMap[["s-Path_214", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_214", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Save", "s-Path_214"]; 

	widgets.descriptionMap[["s-Bg_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Menu minimum width", "s-Menu-minimum-width_3"]; 

	widgets.descriptionMap[["s-Item_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Item_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Menu minimum width", "s-Menu-minimum-width_3"]; 

	widgets.descriptionMap[["s-Paragraph_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Menu minimum width", "s-Menu-minimum-width_3"]; 

	widgets.descriptionMap[["s-Item_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Item_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Menu minimum width", "s-Menu-minimum-width_3"]; 

	widgets.descriptionMap[["s-Paragraph_12", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_12", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Menu minimum width", "s-Menu-minimum-width_3"]; 

	widgets.descriptionMap[["s-Hotspot_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Basic with icons", "s-Group_43"]; 

	widgets.descriptionMap[["s-Rectangle_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Filled", "s-Group_3"]; 

	widgets.descriptionMap[["s-Paragraph_17", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_17", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Headline Small", "s-Paragraph_17"]; 

	widgets.descriptionMap[["s-Button_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Outlined button", "s-Button_8"]; 

	widgets.descriptionMap[["s-Paragraph_16", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_16", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Body small", "s-Paragraph_16"]; 

	widgets.descriptionMap[["s-Paragraph_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Headline Small", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Button_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Outlined button", "s-Button_3"]; 

	widgets.descriptionMap[["s-Paragraph_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Body small", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Button_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Tonal", "s-Button_6"]; 

	widgets.descriptionMap[["s-Panel_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Dropdown input", "s-Dropdown_1"]; 

	widgets.descriptionMap[["s-Rectangle_14", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_14", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Dropdown input", "s-Dropdown_1"]; 

	widgets.descriptionMap[["s-Rectangle_15", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_15", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Dropdown input", "s-Dropdown_1"]; 

	widgets.descriptionMap[["s-Rectangle_16", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Dropdown input", "s-Dropdown_1"]; 

	widgets.descriptionMap[["s-Rectangle_17", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_17", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Dropdown input", "s-Dropdown_1"]; 

	widgets.descriptionMap[["s-Rectangle_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Dropdown input", "s-Dropdown_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Dropdown input", "s-Dropdown_1"]; 

	widgets.descriptionMap[["s-Rectangle_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Dropdown input", "s-Dropdown_1"]; 

	widgets.descriptionMap[["s-Input_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Input_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Input field", "s-Input_5"]; 

	widgets.descriptionMap[["s-Paragraph_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Dropdown input", "s-Dropdown_1"]; 

	widgets.descriptionMap[["s-Path_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Dropdown input", "s-Dropdown_1"]; 

	widgets.descriptionMap[["s-Button_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Tonal", "s-Button_4"]; 

	widgets.descriptionMap[["s-Path_479", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_479", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["View week", "s-Path_479"]; 

	widgets.descriptionMap[["s-Path_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation drawer", "s-Group_1"]; 

	widgets.descriptionMap[["s-Rectangle_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation drawer", "s-Group_1"]; 

	widgets.descriptionMap[["s-Rectangle_11", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_11", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation drawer", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation drawer", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation drawer", "s-Group_1"]; 

	widgets.descriptionMap[["s-Rectangle_12", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_12", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation drawer", "s-Group_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation drawer", "s-Group_1"]; 

	widgets.descriptionMap[["s-Rectangle_13", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_13", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation drawer", "s-Group_1"]; 

	widgets.descriptionMap[["s-Paragraph_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation drawer", "s-Group_1"]; 

	widgets.descriptionMap[["s-Rectangle_18", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_18", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation drawer", "s-Group_1"]; 

	widgets.descriptionMap[["s-Paragraph_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation drawer", "s-Group_1"]; 

	widgets.descriptionMap[["s-Rectangle_19", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_19", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation drawer", "s-Group_1"]; 

	widgets.descriptionMap[["s-Paragraph_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation drawer", "s-Group_1"]; 

	widgets.descriptionMap[["s-Rectangle_20", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_20", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation drawer", "s-Group_1"]; 

	widgets.descriptionMap[["s-Paragraph_9", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation drawer", "s-Group_1"]; 

	widgets.descriptionMap[["s-Rectangle_21", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_21", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation drawer", "s-Group_1"]; 

	widgets.descriptionMap[["s-Paragraph_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation drawer", "s-Group_1"]; 

	widgets.descriptionMap[["s-Rectangle_22", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_22", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation drawer", "s-Group_1"]; 

	widgets.descriptionMap[["s-Paragraph_11", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_11", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation drawer", "s-Group_1"]; 

	widgets.descriptionMap[["s-Rectangle_23", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_23", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation drawer", "s-Group_1"]; 

	widgets.descriptionMap[["s-Paragraph_13", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_13", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation drawer", "s-Group_1"]; 

	widgets.descriptionMap[["s-Rectangle_27", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_27", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation drawer", "s-Group_1"]; 

	widgets.descriptionMap[["s-Paragraph_14", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_14", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation drawer", "s-Group_1"]; 

	widgets.descriptionMap[["s-Rectangle_28", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_28", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation drawer", "s-Group_1"]; 

	widgets.descriptionMap[["s-Paragraph_15", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_15", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation drawer", "s-Group_1"]; 

	widgets.descriptionMap[["s-Paragraph_18", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_18", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation drawer", "s-Group_1"]; 

	widgets.descriptionMap[["s-Paragraph_19", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_19", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation drawer", "s-Group_1"]; 

	widgets.descriptionMap[["s-Paragraph_20", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_20", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation drawer", "s-Group_1"]; 

	widgets.descriptionMap[["s-Paragraph_21", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_21", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation drawer", "s-Group_1"]; 

	widgets.descriptionMap[["s-Paragraph_22", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_22", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Navigation drawer", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Dollar", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Email", "s-Path_8"]; 

	widgets.descriptionMap[["s-Path_9", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Account circle", "s-Path_9"]; 

	widgets.descriptionMap[["s-Path_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Learn", "s-Path_10"]; 

	widgets.descriptionMap[["s-Path_11", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Quote", "s-Path_11"]; 

	widgets.descriptionMap[["s-Path_12", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_12", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Gesture", "s-Path_12"]; 

	widgets.descriptionMap[["s-Path_13", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_13", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Videocam", "s-Path_13"]; 

	widgets.descriptionMap[["s-Path_14", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_14", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Book", "s-Path_14"]; 

	widgets.descriptionMap[["s-Path_15", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["More horizontal", "s-Path_15"]; 

	widgets.descriptionMap[["s-Path_16", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_16", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Clock", "s-Group_17"]; 

	widgets.descriptionMap[["s-Path_17", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_17", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Clock", "s-Group_17"]; 

	
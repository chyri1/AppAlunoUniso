jQuery("#simulation")
  .on("click", ".s-79498c0b-49b0-46ef-80be-7757a4ada859 .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(jimUtil.isAlternateModeActive()) return;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Hotspot_2")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Rectangle_16" ],
                    "effect": {
                      "type": "fade",
                      "duration": 200
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Rectangle_19","#s-Rectangle_20","#s-Rectangle_21" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d12245cc-1680-458d-89dd-4f0d7fb22724"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Cell_6")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Rectangle_19" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Rectangle_20","#s-Rectangle_21","#s-Rectangle_16" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Hotspot_3")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Rectangle_19" ],
                    "effect": {
                      "type": "fade",
                      "duration": 200
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Rectangle_20","#s-Rectangle_21","#s-Rectangle_16" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/79498c0b-49b0-46ef-80be-7757a4ada859"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Hotspot_4")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Rectangle_20" ],
                    "effect": {
                      "type": "fade",
                      "duration": 200
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Rectangle_19","#s-Rectangle_21","#s-Rectangle_16" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/e9a9523c-cc73-4d87-bee5-6489684988bc"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Hotspot_5")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Rectangle_21" ],
                    "effect": {
                      "type": "fade",
                      "duration": 200
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Rectangle_19","#s-Rectangle_20","#s-Rectangle_16" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/0d085857-028e-492b-867d-a316088a856b"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_2")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_2 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#D8CFE8"
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_3 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#F3EDF7"
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_2 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#D8CFE8"
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_3 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#F3EDF7"
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_3")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_3 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#D8CFE8"
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_2 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#F3EDF7"
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_2")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_3 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#D8CFE8"
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_2 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#F3EDF7"
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button_22")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Button_22 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "rgba(103,80,164,0.08)"
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Button_22 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "rgba(255,255,255,0.0)"
                    }
                  } ],
                  "exectype": "timed",
                  "delay": 200
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button_23")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Button_23 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "rgba(103,80,164,0.08)"
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Button_23 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "rgba(255,255,255,0.0)"
                    }
                  } ],
                  "exectype": "timed",
                  "delay": 200
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Path_4")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Group_6" ],
                    "top": {
                      "type": "movetoposition",
                      "value": "0.0"
                    },
                    "left": {
                      "type": "movetoposition",
                      "value": "0.0"
                    },
                    "containment": false,
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 400
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Rectangle_4" ],
                    "effect": {
                      "type": "fade",
                      "duration": 200
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_4")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Group_6" ],
                    "top": {
                      "type": "movetoposition",
                      "value": "0.0"
                    },
                    "left": {
                      "type": "movetoposition",
                      "value": "-360.0"
                    },
                    "containment": false,
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 400
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Rectangle_4" ],
                    "effect": {
                      "type": "fade",
                      "duration": 200
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_6")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_6 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#E8DEF8"
                    }
                  },{
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 200
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_10 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_14 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_15 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_9 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_7 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_8 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_11 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_13 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_12 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#F3EDF7"
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_3")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_6 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#E8DEF8"
                    }
                  },{
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 200
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_10 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_14 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_15 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_9 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_7 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_8 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_11 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_13 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_12 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#F3EDF7"
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_7")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_7 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#E8DEF8"
                    }
                  },{
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 200
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_10 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_6 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_14 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_15 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_9 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_8 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_11 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_13 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_12 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#F3EDF7"
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_4")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_7 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#E8DEF8"
                    }
                  },{
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 200
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_10 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_6 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_14 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_15 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_9 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_8 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_11 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_13 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_12 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#F3EDF7"
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/fd348695-5a87-4b52-8995-1c4f1f396771"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_8")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_8 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#E8DEF8"
                    }
                  },{
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 200
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_10 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_6 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_14 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_7 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_9 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_15 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_11 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_12 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_13 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_5 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#F3EDF7"
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_5")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_8 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#E8DEF8"
                    }
                  },{
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 200
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_14 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_13 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_7 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_12 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_10 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_9 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_6 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_15 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_11 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_5 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#F3EDF7"
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_9")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_9 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#E8DEF8"
                    }
                  },{
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 200
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_10 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_6 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_14 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_7 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_9 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_15 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_8 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_11 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_12 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_13 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#F3EDF7"
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_6")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_9 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#E8DEF8"
                    }
                  },{
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 200
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_14 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_13 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_7 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_12 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_10 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_6 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_15 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_8 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_11 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#F3EDF7"
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_10")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_10 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#E8DEF8"
                    }
                  },{
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 200
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_10 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_6 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_14 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_7 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_9 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_15 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_8 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_11 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_12 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_13 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_5 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#F3EDF7"
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_7")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_10 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#E8DEF8"
                    }
                  },{
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 200
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_14 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_13 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_7 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_12 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_9 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_6 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_15 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_8 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_11 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_5 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#F3EDF7"
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_11")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_11 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#E8DEF8"
                    }
                  },{
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 200
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_10 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_6 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_14 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_7 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_9 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_15 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_8 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_11 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_12 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_13 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#F3EDF7"
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_8")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_11 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#E8DEF8"
                    }
                  },{
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 200
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_14 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_13 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_7 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_12 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_10 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_9 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_6 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_15 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_8 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#F3EDF7"
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_12")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_12 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#E8DEF8"
                    }
                  },{
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 200
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_10 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_6 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_14 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_7 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_9 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_15 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_8 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_11 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_13 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_5 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#F3EDF7"
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/0d085857-028e-492b-867d-a316088a856b"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_9")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_12 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#E8DEF8"
                    }
                  },{
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 200
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_14 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_13 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_7 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_10 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_9 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_6 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_15 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_8 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_11 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_5 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#F3EDF7"
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/0d085857-028e-492b-867d-a316088a856b"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_13")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_13 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#E8DEF8"
                    }
                  },{
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 200
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_10 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_6 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_14 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_7 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_9 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_15 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_8 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_11 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_12 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#F3EDF7"
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/e9a9523c-cc73-4d87-bee5-6489684988bc"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_10")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_13 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#E8DEF8"
                    }
                  },{
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 200
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_10 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_6 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_14 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_7 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_9 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_15 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_8 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_11 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_12 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#F3EDF7"
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/e9a9523c-cc73-4d87-bee5-6489684988bc"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_14")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_14 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#E8DEF8"
                    }
                  },{
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 200
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_10 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_6 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_7 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_9 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_15 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_8 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_11 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_12 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_13 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#F3EDF7"
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/79498c0b-49b0-46ef-80be-7757a4ada859"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_11")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_14 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#E8DEF8"
                    }
                  },{
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 200
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_13 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_7 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_12 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_10 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_9 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_6 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_15 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_8 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_11 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#F3EDF7"
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/79498c0b-49b0-46ef-80be-7757a4ada859"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_15")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_15 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#E8DEF8"
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_10 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_6 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_14 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_9 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_7 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_8 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_11 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_13 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_12 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#F3EDF7"
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d12245cc-1680-458d-89dd-4f0d7fb22724"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_12")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_15 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#E8DEF8"
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "target": [ "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_10 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_6 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_14 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_9 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_7 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_8 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_11 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_13 > .backgroundLayer > .colorLayer",
                  "#s-79498c0b-49b0-46ef-80be-7757a4ada859 #s-Rectangle_12 > .backgroundLayer > .colorLayer" ],
                    "attributes": {
                      "background-color": "#F3EDF7"
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d12245cc-1680-458d-89dd-4f0d7fb22724"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_13")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d12245cc-1680-458d-89dd-4f0d7fb22724"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("click", ".s-79498c0b-49b0-46ef-80be-7757a4ada859 .toggle", function(event, data) {
    var jEvent, jFirer, cases;
    if(jimUtil.isAlternateModeActive()) return;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Hotspot_1")) {
      if(jFirer.data("jimHasToggle")) {
        jFirer.removeData("jimHasToggle");
        jEvent.undoCases(jFirer);
      } else {
        jFirer.data("jimHasToggle", true);
        event.backupState = true;
        event.target = jFirer;
        cases = [
          {
            "blocks": [
              {
                "actions": [
                  {
                    "action": "jimHide",
                    "parameter": {
                      "target": [ "#s-Group_2" ]
                    },
                    "exectype": "serial",
                    "delay": 0
                  }
                ]
              }
            ],
            "exectype": "serial",
            "delay": 0
          }
        ];
        jEvent.launchCases(cases);
      }
    }
  });
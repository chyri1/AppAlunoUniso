(function(window, undefined) {

  var jimLinks = {
    "7605ba91-d883-4480-96b8-df901befd8ab" : {
      "Button_5" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "79498c0b-49b0-46ef-80be-7757a4ada859" : {
      "Hotspot_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_3" : [
        "79498c0b-49b0-46ef-80be-7757a4ada859"
      ],
      "Hotspot_4" : [
        "e9a9523c-cc73-4d87-bee5-6489684988bc"
      ],
      "Hotspot_5" : [
        "0d085857-028e-492b-867d-a316088a856b"
      ],
      "Paragraph_4" : [
        "fd348695-5a87-4b52-8995-1c4f1f396771"
      ],
      "Rectangle_12" : [
        "0d085857-028e-492b-867d-a316088a856b"
      ],
      "Paragraph_9" : [
        "0d085857-028e-492b-867d-a316088a856b"
      ],
      "Rectangle_13" : [
        "e9a9523c-cc73-4d87-bee5-6489684988bc"
      ],
      "Paragraph_10" : [
        "e9a9523c-cc73-4d87-bee5-6489684988bc"
      ],
      "Rectangle_14" : [
        "79498c0b-49b0-46ef-80be-7757a4ada859"
      ],
      "Paragraph_11" : [
        "79498c0b-49b0-46ef-80be-7757a4ada859"
      ],
      "Rectangle_15" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_12" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_13" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "0d085857-028e-492b-867d-a316088a856b" : {
      "Hotspot_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_3" : [
        "79498c0b-49b0-46ef-80be-7757a4ada859"
      ],
      "Hotspot_4" : [
        "e9a9523c-cc73-4d87-bee5-6489684988bc"
      ],
      "Hotspot_5" : [
        "0d085857-028e-492b-867d-a316088a856b"
      ],
      "Button_5" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_2" : [
        "fd348695-5a87-4b52-8995-1c4f1f396771"
      ],
      "Rectangle_12" : [
        "0d085857-028e-492b-867d-a316088a856b"
      ],
      "Paragraph_7" : [
        "0d085857-028e-492b-867d-a316088a856b"
      ],
      "Rectangle_13" : [
        "e9a9523c-cc73-4d87-bee5-6489684988bc"
      ],
      "Paragraph_8" : [
        "e9a9523c-cc73-4d87-bee5-6489684988bc"
      ],
      "Rectangle_14" : [
        "79498c0b-49b0-46ef-80be-7757a4ada859"
      ],
      "Paragraph_9" : [
        "79498c0b-49b0-46ef-80be-7757a4ada859"
      ],
      "Rectangle_15" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_10" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_11" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "fd348695-5a87-4b52-8995-1c4f1f396771" : {
      "Hotspot_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_3" : [
        "79498c0b-49b0-46ef-80be-7757a4ada859"
      ],
      "Hotspot_4" : [
        "e9a9523c-cc73-4d87-bee5-6489684988bc"
      ],
      "Hotspot_5" : [
        "0d085857-028e-492b-867d-a316088a856b"
      ],
      "Button_5" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_5" : [
        "fd348695-5a87-4b52-8995-1c4f1f396771"
      ],
      "Rectangle_15" : [
        "0d085857-028e-492b-867d-a316088a856b"
      ],
      "Paragraph_10" : [
        "0d085857-028e-492b-867d-a316088a856b"
      ],
      "Rectangle_16" : [
        "e9a9523c-cc73-4d87-bee5-6489684988bc"
      ],
      "Paragraph_11" : [
        "e9a9523c-cc73-4d87-bee5-6489684988bc"
      ],
      "Rectangle_17" : [
        "79498c0b-49b0-46ef-80be-7757a4ada859"
      ],
      "Paragraph_12" : [
        "79498c0b-49b0-46ef-80be-7757a4ada859"
      ],
      "Rectangle_18" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_13" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_14" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "e9a9523c-cc73-4d87-bee5-6489684988bc" : {
      "Hotspot_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_3" : [
        "79498c0b-49b0-46ef-80be-7757a4ada859"
      ],
      "Hotspot_4" : [
        "e9a9523c-cc73-4d87-bee5-6489684988bc"
      ],
      "Hotspot_5" : [
        "0d085857-028e-492b-867d-a316088a856b"
      ],
      "Paragraph_4" : [
        "fd348695-5a87-4b52-8995-1c4f1f396771"
      ],
      "Rectangle_12" : [
        "0d085857-028e-492b-867d-a316088a856b"
      ],
      "Paragraph_9" : [
        "0d085857-028e-492b-867d-a316088a856b"
      ],
      "Rectangle_13" : [
        "e9a9523c-cc73-4d87-bee5-6489684988bc"
      ],
      "Paragraph_10" : [
        "e9a9523c-cc73-4d87-bee5-6489684988bc"
      ],
      "Rectangle_14" : [
        "79498c0b-49b0-46ef-80be-7757a4ada859"
      ],
      "Paragraph_11" : [
        "79498c0b-49b0-46ef-80be-7757a4ada859"
      ],
      "Rectangle_15" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_12" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_13" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "7079afc0-5274-4ccc-ae86-fe1805e8e611" : {
      "Button_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_6" : [
        "0d085857-028e-492b-867d-a316088a856b"
      ],
      "Hotspot_14" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_13" : [
        "79498c0b-49b0-46ef-80be-7757a4ada859"
      ],
      "Hotspot_12" : [
        "e9a9523c-cc73-4d87-bee5-6489684988bc"
      ],
      "Hotspot_11" : [
        "0d085857-028e-492b-867d-a316088a856b"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Hotspot_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_3" : [
        "79498c0b-49b0-46ef-80be-7757a4ada859"
      ],
      "Hotspot_4" : [
        "e9a9523c-cc73-4d87-bee5-6489684988bc"
      ],
      "Hotspot_5" : [
        "0d085857-028e-492b-867d-a316088a856b"
      ],
      "Paragraph_4" : [
        "fd348695-5a87-4b52-8995-1c4f1f396771"
      ],
      "Rectangle_22" : [
        "0d085857-028e-492b-867d-a316088a856b"
      ],
      "Paragraph_11" : [
        "0d085857-028e-492b-867d-a316088a856b"
      ],
      "Rectangle_23" : [
        "e9a9523c-cc73-4d87-bee5-6489684988bc"
      ],
      "Paragraph_13" : [
        "e9a9523c-cc73-4d87-bee5-6489684988bc"
      ],
      "Rectangle_27" : [
        "79498c0b-49b0-46ef-80be-7757a4ada859"
      ],
      "Paragraph_14" : [
        "79498c0b-49b0-46ef-80be-7757a4ada859"
      ],
      "Rectangle_28" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_15" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_18" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);
(function(window, undefined) {
  var dictionary = {
    "7605ba91-d883-4480-96b8-df901befd8ab": "Login",
    "79498c0b-49b0-46ef-80be-7757a4ada859": "Boleto",
    "0d085857-028e-492b-867d-a316088a856b": "Acadêmico",
    "fd348695-5a87-4b52-8995-1c4f1f396771": "Biblioteca",
    "e9a9523c-cc73-4d87-bee5-6489684988bc": "Mensagens",
    "7079afc0-5274-4ccc-ae86-fe1805e8e611": "Testes",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Horário",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);